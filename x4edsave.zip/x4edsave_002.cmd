rem nologs xenonup nomods nodef nocargo logshipsplayer
rem x4edsave.exe save_002.xml "nologs xenonup nomods nodef nocargo" > x4ed_002.txt
x4edsave.exe save_002.xml "ALL" > x4ed_002.txt