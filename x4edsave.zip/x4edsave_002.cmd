rem "statistics playerup playercargoup nologs xenoncargoup xenonup nomods nodef nocargo"
rem x4edsave.exe save_002.xml "statistics playerup xenonup xenoncargoup nodef" "TGJ-572 XBM-952 EVH-617" > x4ed_002.txt
rem x4edsave.exe save_002.xml "statistics playerup xenonup" > x4ed_002.txt
rem x4edsave.exe save_002.xml "statistics playerup xenonup xenoncargoup nodef nocargo nologs" "owner=\"boron\" owner=\"terran\" owner=\"argon\" owner=\"split\" owner=\"paranid\"" > x4ed_002.txt
x4edsave.exe save_002.xml "statistics playerup xenonup xenoncargoup nomods nodef nocargo breakships nologs" > x4ed_002.txt
