rem A test to test the capture of the universe by xenon
x4edsave.exe save_001.xml "statistics playerup xenonup xenoncargoup nomods nodef nocargo breakships nologs" > x4ed_001.txt
