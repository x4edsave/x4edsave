rem nologs xenonup nomods nodef nocargo logshipsplayer
rem x4edsave.exe save_001.xml "nologs xenonup nomods nodef nocargo" > x4ed_001.txt
x4edsave.exe save_001.xml "ALL" > x4ed_001.txt