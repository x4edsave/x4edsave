rem "statistics playerup playercargoup nologs xenoncargoup xenonup nomods nodef nocargo"
x4edsave.exe save_001.xml "statistics xenonup xenoncargoup nologs" > x4ed_001.txt