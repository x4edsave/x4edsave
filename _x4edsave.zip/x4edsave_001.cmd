rem x4edsave.exe save_001.xml "ALL" > x4ed_001.txt
x4edsave.exe
rem x4edsave.exe save_001.xml "nocargo" > x4ed_001.txt
x4edsave.exe save_001.xml "nologs xenonup nomods nodef" > x4ed_001.txt